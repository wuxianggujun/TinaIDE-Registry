
get_filename_component(_raylib_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "raylib Android package requires ANDROID_ABI")
endif()

set(_raylib_LIBRARY "${_raylib_ROOT}/lib/${ANDROID_ABI}/libraylib.so")
if(NOT EXISTS "${_raylib_LIBRARY}")
    message(FATAL_ERROR "raylib package does not contain libraylib.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET raylib)
    add_library(raylib SHARED IMPORTED)
    set_target_properties(raylib PROPERTIES
        IMPORTED_LOCATION "${_raylib_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_raylib_ROOT}/include"
        
    )
endif()
if(NOT TARGET raylib::raylib)
    add_library(raylib::raylib ALIAS raylib)
endif()

set(raylib_FOUND TRUE)
unset(_raylib_LIBRARY)
unset(_raylib_ROOT)
