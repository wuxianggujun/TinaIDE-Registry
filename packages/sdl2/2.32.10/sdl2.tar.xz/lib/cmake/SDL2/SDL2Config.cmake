set(SDL2_VERSION "2.32.10")
get_filename_component(_SDL2_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL2 Android package requires ANDROID_ABI")
endif()

set(_SDL2_LIBRARY "${_SDL2_ROOT}/lib/${ANDROID_ABI}/libSDL2.so")
if(NOT EXISTS "${_SDL2_LIBRARY}")
    message(FATAL_ERROR "SDL2 package does not contain libSDL2.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL2::SDL2)
    add_library(SDL2::SDL2 SHARED IMPORTED)
    set_target_properties(SDL2::SDL2 PROPERTIES
        IMPORTED_LOCATION "${_SDL2_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL2_ROOT}/include;${_SDL2_ROOT}/include/SDL2"
    )
endif()

set(SDL2_FOUND TRUE)
unset(_SDL2_LIBRARY)
unset(_SDL2_ROOT)
