
get_filename_component(_SDL3_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL3 Android package requires ANDROID_ABI")
endif()

set(_SDL3_LIBRARY "${_SDL3_ROOT}/lib/${ANDROID_ABI}/libSDL3.so")
if(NOT EXISTS "${_SDL3_LIBRARY}")
    message(FATAL_ERROR "SDL3 package does not contain libSDL3.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL3::SDL3)
    add_library(SDL3::SDL3 SHARED IMPORTED)
    set_target_properties(SDL3::SDL3 PROPERTIES
        IMPORTED_LOCATION "${_SDL3_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL3_ROOT}/include;${_SDL3_ROOT}/include/SDL3"
        
    )
endif()
if(NOT TARGET SDL3::SDL3-shared)
    add_library(SDL3::SDL3-shared ALIAS SDL3::SDL3)
endif()

set(SDL3_FOUND TRUE)
unset(_SDL3_LIBRARY)
unset(_SDL3_ROOT)
