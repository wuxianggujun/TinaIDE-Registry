include(CMakeFindDependencyMacro)
find_dependency(SDL2 CONFIG)
get_filename_component(_SDL2_image_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL2_image Android package requires ANDROID_ABI")
endif()

set(_SDL2_image_LIBRARY "${_SDL2_image_ROOT}/lib/${ANDROID_ABI}/libSDL2_image.so")
if(NOT EXISTS "${_SDL2_image_LIBRARY}")
    message(FATAL_ERROR "SDL2_image package does not contain libSDL2_image.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL2_image::SDL2_image)
    add_library(SDL2_image::SDL2_image SHARED IMPORTED)
    set_target_properties(SDL2_image::SDL2_image PROPERTIES
        IMPORTED_LOCATION "${_SDL2_image_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL2_image_ROOT}/include;${_SDL2_image_ROOT}/include/SDL2"
        INTERFACE_LINK_LIBRARIES "SDL2::SDL2"
    )
endif()
if(NOT TARGET SDL2_image::SDL2_image-shared)
    add_library(SDL2_image::SDL2_image-shared ALIAS SDL2_image::SDL2_image)
endif()

set(SDL2_image_FOUND TRUE)
unset(_SDL2_image_LIBRARY)
unset(_SDL2_image_ROOT)
