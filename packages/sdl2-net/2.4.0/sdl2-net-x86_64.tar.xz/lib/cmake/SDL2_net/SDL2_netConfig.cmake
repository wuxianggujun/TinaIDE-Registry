include(CMakeFindDependencyMacro)
find_dependency(SDL2 CONFIG)
get_filename_component(_SDL2_net_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL2_net Android package requires ANDROID_ABI")
endif()

set(_SDL2_net_LIBRARY "${_SDL2_net_ROOT}/lib/${ANDROID_ABI}/libSDL2_net.so")
if(NOT EXISTS "${_SDL2_net_LIBRARY}")
    message(FATAL_ERROR "SDL2_net package does not contain libSDL2_net.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL2_net::SDL2_net)
    add_library(SDL2_net::SDL2_net SHARED IMPORTED)
    set_target_properties(SDL2_net::SDL2_net PROPERTIES
        IMPORTED_LOCATION "${_SDL2_net_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL2_net_ROOT}/include;${_SDL2_net_ROOT}/include/SDL2"
        INTERFACE_LINK_LIBRARIES "SDL2::SDL2"
    )
endif()
if(NOT TARGET SDL2_net::SDL2_net-shared)
    add_library(SDL2_net::SDL2_net-shared ALIAS SDL2_net::SDL2_net)
endif()

set(SDL2_net_FOUND TRUE)
unset(_SDL2_net_LIBRARY)
unset(_SDL2_net_ROOT)
