include(CMakeFindDependencyMacro)
find_dependency(SDL3 CONFIG)
get_filename_component(_SDL3_mixer_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL3_mixer Android package requires ANDROID_ABI")
endif()

set(_SDL3_mixer_LIBRARY "${_SDL3_mixer_ROOT}/lib/${ANDROID_ABI}/libSDL3_mixer.so")
if(NOT EXISTS "${_SDL3_mixer_LIBRARY}")
    message(FATAL_ERROR "SDL3_mixer package does not contain libSDL3_mixer.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL3_mixer::SDL3_mixer)
    add_library(SDL3_mixer::SDL3_mixer SHARED IMPORTED)
    set_target_properties(SDL3_mixer::SDL3_mixer PROPERTIES
        IMPORTED_LOCATION "${_SDL3_mixer_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL3_mixer_ROOT}/include;${_SDL3_mixer_ROOT}/include/SDL3_mixer"
        INTERFACE_LINK_LIBRARIES "SDL3::SDL3"
    )
endif()
if(NOT TARGET SDL3_mixer::SDL3_mixer-shared)
    add_library(SDL3_mixer::SDL3_mixer-shared ALIAS SDL3_mixer::SDL3_mixer)
endif()

set(SDL3_mixer_FOUND TRUE)
unset(_SDL3_mixer_LIBRARY)
unset(_SDL3_mixer_ROOT)
