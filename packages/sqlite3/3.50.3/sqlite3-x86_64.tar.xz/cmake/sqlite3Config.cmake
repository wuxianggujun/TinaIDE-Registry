if(TARGET SQLite::SQLite3)
    return()
endif()
get_filename_component(_SQLITE3_PREFIX "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)
if(NOT ANDROID_ABI)
    set(ANDROID_ABI "arm64-v8a")
endif()
add_library(SQLite::SQLite3 STATIC IMPORTED)
set_target_properties(SQLite::SQLite3 PROPERTIES
    IMPORTED_LOCATION "${_SQLITE3_PREFIX}/lib/${ANDROID_ABI}/libsqlite3.a"
    INTERFACE_INCLUDE_DIRECTORIES "${_SQLITE3_PREFIX}/include"
)
