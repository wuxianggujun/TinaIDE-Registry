include(CMakeFindDependencyMacro)
find_dependency(SDL2 CONFIG)
get_filename_component(_SDL2_ttf_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL2_ttf Android package requires ANDROID_ABI")
endif()

set(_SDL2_ttf_LIBRARY "${_SDL2_ttf_ROOT}/lib/${ANDROID_ABI}/libSDL2_ttf.so")
if(NOT EXISTS "${_SDL2_ttf_LIBRARY}")
    message(FATAL_ERROR "SDL2_ttf package does not contain libSDL2_ttf.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL2_ttf::SDL2_ttf)
    add_library(SDL2_ttf::SDL2_ttf SHARED IMPORTED)
    set_target_properties(SDL2_ttf::SDL2_ttf PROPERTIES
        IMPORTED_LOCATION "${_SDL2_ttf_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL2_ttf_ROOT}/include;${_SDL2_ttf_ROOT}/include/SDL2"
        INTERFACE_LINK_LIBRARIES "SDL2::SDL2"
    )
endif()
if(NOT TARGET SDL2_ttf::SDL2_ttf-shared)
    add_library(SDL2_ttf::SDL2_ttf-shared ALIAS SDL2_ttf::SDL2_ttf)
endif()

set(SDL2_ttf_FOUND TRUE)
unset(_SDL2_ttf_LIBRARY)
unset(_SDL2_ttf_ROOT)
