if(TARGET zstd::libzstd_static)
    return()
endif()
get_filename_component(_ZSTD_PREFIX "${CMAKE_CURRENT_LIST_DIR}/.." ABSOLUTE)
if(NOT ANDROID_ABI)
    set(ANDROID_ABI "arm64-v8a")
endif()
add_library(zstd::libzstd_static STATIC IMPORTED)
set_target_properties(zstd::libzstd_static PROPERTIES
    IMPORTED_LOCATION "${_ZSTD_PREFIX}/lib/${ANDROID_ABI}/libzstd.a"
    INTERFACE_INCLUDE_DIRECTORIES "${_ZSTD_PREFIX}/include"
)
if(NOT TARGET zstd::zstd)
    add_library(zstd::zstd INTERFACE IMPORTED)
    set_property(TARGET zstd::zstd PROPERTY INTERFACE_LINK_LIBRARIES zstd::libzstd_static)
endif()
