
get_filename_component(_box2d_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "Box2D Android package requires ANDROID_ABI")
endif()

set(_box2d_LIBRARY "${_box2d_ROOT}/lib/${ANDROID_ABI}/libbox2d.a")
if(NOT EXISTS "${_box2d_LIBRARY}")
    message(FATAL_ERROR "Box2D package does not contain libbox2d.a for ${ANDROID_ABI}")
endif()

if(NOT TARGET box2d::box2d)
    add_library(box2d::box2d STATIC IMPORTED)
    set_target_properties(box2d::box2d PROPERTIES
        IMPORTED_LOCATION "${_box2d_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_box2d_ROOT}/include;${_box2d_ROOT}/include/box2d"
        
    )
endif()
if(NOT TARGET box2d)
    add_library(box2d ALIAS box2d::box2d)
endif()

set(box2d_FOUND TRUE)
unset(_box2d_LIBRARY)
unset(_box2d_ROOT)
