include(CMakeFindDependencyMacro)
find_dependency(SDL3 CONFIG)
get_filename_component(_SDL3_image_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL3_image Android package requires ANDROID_ABI")
endif()

set(_SDL3_image_LIBRARY "${_SDL3_image_ROOT}/lib/${ANDROID_ABI}/libSDL3_image.so")
if(NOT EXISTS "${_SDL3_image_LIBRARY}")
    message(FATAL_ERROR "SDL3_image package does not contain libSDL3_image.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL3_image::SDL3_image)
    add_library(SDL3_image::SDL3_image SHARED IMPORTED)
    set_target_properties(SDL3_image::SDL3_image PROPERTIES
        IMPORTED_LOCATION "${_SDL3_image_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL3_image_ROOT}/include;${_SDL3_image_ROOT}/include/SDL3_image"
        INTERFACE_LINK_LIBRARIES "SDL3::SDL3"
    )
endif()
if(NOT TARGET SDL3_image::SDL3_image-shared)
    add_library(SDL3_image::SDL3_image-shared ALIAS SDL3_image::SDL3_image)
endif()

set(SDL3_image_FOUND TRUE)
unset(_SDL3_image_LIBRARY)
unset(_SDL3_image_ROOT)
