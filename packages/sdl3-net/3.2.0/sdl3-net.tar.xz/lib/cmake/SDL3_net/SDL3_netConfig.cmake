include(CMakeFindDependencyMacro)
find_dependency(SDL3 CONFIG)
get_filename_component(_SDL3_net_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL3_net Android package requires ANDROID_ABI")
endif()

set(_SDL3_net_LIBRARY "${_SDL3_net_ROOT}/lib/${ANDROID_ABI}/libSDL3_net.so")
if(NOT EXISTS "${_SDL3_net_LIBRARY}")
    message(FATAL_ERROR "SDL3_net package does not contain libSDL3_net.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL3_net::SDL3_net)
    add_library(SDL3_net::SDL3_net SHARED IMPORTED)
    set_target_properties(SDL3_net::SDL3_net PROPERTIES
        IMPORTED_LOCATION "${_SDL3_net_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL3_net_ROOT}/include;${_SDL3_net_ROOT}/include/SDL3_net"
        INTERFACE_LINK_LIBRARIES "SDL3::SDL3"
    )
endif()
if(NOT TARGET SDL3_net::SDL3_net-shared)
    add_library(SDL3_net::SDL3_net-shared ALIAS SDL3_net::SDL3_net)
endif()

set(SDL3_net_FOUND TRUE)
unset(_SDL3_net_LIBRARY)
unset(_SDL3_net_ROOT)
