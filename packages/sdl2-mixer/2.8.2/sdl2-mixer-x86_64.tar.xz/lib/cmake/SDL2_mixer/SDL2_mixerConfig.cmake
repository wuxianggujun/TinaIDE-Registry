include(CMakeFindDependencyMacro)
find_dependency(SDL2 CONFIG)
get_filename_component(_SDL2_mixer_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL2_mixer Android package requires ANDROID_ABI")
endif()

set(_SDL2_mixer_LIBRARY "${_SDL2_mixer_ROOT}/lib/${ANDROID_ABI}/libSDL2_mixer.so")
if(NOT EXISTS "${_SDL2_mixer_LIBRARY}")
    message(FATAL_ERROR "SDL2_mixer package does not contain libSDL2_mixer.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL2_mixer::SDL2_mixer)
    add_library(SDL2_mixer::SDL2_mixer SHARED IMPORTED)
    set_target_properties(SDL2_mixer::SDL2_mixer PROPERTIES
        IMPORTED_LOCATION "${_SDL2_mixer_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL2_mixer_ROOT}/include;${_SDL2_mixer_ROOT}/include/SDL2"
        INTERFACE_LINK_LIBRARIES "SDL2::SDL2"
    )
endif()
if(NOT TARGET SDL2_mixer::SDL2_mixer-shared)
    add_library(SDL2_mixer::SDL2_mixer-shared ALIAS SDL2_mixer::SDL2_mixer)
endif()

set(SDL2_mixer_FOUND TRUE)
unset(_SDL2_mixer_LIBRARY)
unset(_SDL2_mixer_ROOT)
