include(CMakeFindDependencyMacro)
find_dependency(SDL3 CONFIG)
get_filename_component(_SDL3_ttf_ROOT "${CMAKE_CURRENT_LIST_DIR}/../../.." ABSOLUTE)

if(NOT ANDROID_ABI)
    message(FATAL_ERROR "SDL3_ttf Android package requires ANDROID_ABI")
endif()

set(_SDL3_ttf_LIBRARY "${_SDL3_ttf_ROOT}/lib/${ANDROID_ABI}/libSDL3_ttf.so")
if(NOT EXISTS "${_SDL3_ttf_LIBRARY}")
    message(FATAL_ERROR "SDL3_ttf package does not contain libSDL3_ttf.so for ${ANDROID_ABI}")
endif()

if(NOT TARGET SDL3_ttf::SDL3_ttf)
    add_library(SDL3_ttf::SDL3_ttf SHARED IMPORTED)
    set_target_properties(SDL3_ttf::SDL3_ttf PROPERTIES
        IMPORTED_LOCATION "${_SDL3_ttf_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${_SDL3_ttf_ROOT}/include;${_SDL3_ttf_ROOT}/include/SDL3_ttf"
        INTERFACE_LINK_LIBRARIES "SDL3::SDL3"
    )
endif()
if(NOT TARGET SDL3_ttf::SDL3_ttf-shared)
    add_library(SDL3_ttf::SDL3_ttf-shared ALIAS SDL3_ttf::SDL3_ttf)
endif()

set(SDL3_ttf_FOUND TRUE)
unset(_SDL3_ttf_LIBRARY)
unset(_SDL3_ttf_ROOT)
