#include <SDL2/SDL.h>

#include <cmath>

namespace {

struct AppState {
    SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    bool running = true;
};

Uint8 pulseColor(float phase, float offset) {
    const float value = (std::sin(phase + offset) + 1.0f) * 0.5f;
    return static_cast<Uint8>(value * 255.0f);
}

void destroyApp(AppState& app) {
    if (app.renderer != nullptr) {
        SDL_DestroyRenderer(app.renderer);
        app.renderer = nullptr;
    }
    if (app.window != nullptr) {
        SDL_DestroyWindow(app.window);
        app.window = nullptr;
    }
    SDL_Quit();
}

}  // namespace

int main(int argc, char* argv[]) {
    (void)argc;
    (void)argv;

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) != 0) {
        SDL_Log("SDL_Init failed: %s", SDL_GetError());
        return 1;
    }

    AppState app;
    app.window = SDL_CreateWindow(
        "{{PROJECT_NAME}}",
        SDL_WINDOWPOS_CENTERED,
        SDL_WINDOWPOS_CENTERED,
        960,
        540,
        SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
    );
    if (app.window == nullptr) {
        SDL_Log("SDL_CreateWindow failed: %s", SDL_GetError());
        destroyApp(app);
        return 1;
    }

    app.renderer = SDL_CreateRenderer(
        app.window,
        -1,
        SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC
    );
    if (app.renderer == nullptr) {
        SDL_Log("SDL_CreateRenderer failed: %s", SDL_GetError());
        destroyApp(app);
        return 1;
    }

    float phase = 0.0f;
    while (app.running) {
        SDL_Event event;
        while (SDL_PollEvent(&event) != 0) {
            if (event.type == SDL_QUIT ||
                (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)) {
                app.running = false;
            }
        }

        phase += 0.02f;
        SDL_SetRenderDrawColor(
            app.renderer,
            pulseColor(phase, 0.0f),
            pulseColor(phase, 2.0f),
            pulseColor(phase, 4.0f),
            255
        );
        SDL_RenderClear(app.renderer);

        SDL_Rect rectangle = {
            180 + static_cast<int>(std::sin(phase) * 80.0f),
            140,
            220,
            220,
        };
        SDL_SetRenderDrawColor(app.renderer, 255, 255, 255, 255);
        SDL_RenderFillRect(app.renderer, &rectangle);
        SDL_RenderPresent(app.renderer);
    }

    destroyApp(app);
    return 0;
}
